# Matches for the database

Drop this ZIP, as it is, into the "Submit a match" form of the database on GitHub (the Contribute page opens it for you), tick the rights box and create the issue. A bot checks the matches again, adds them, and answers on the issue with their links. The files of one match share the same name.

- [x] I have the right to share these matches under the CC0 public-domain dedication (ticked on the Contribute page).
